//*****************************************************************************
//
// uart_echo.c - Example for reading data from and writing data to the UART in
//               an interrupt driven fashion.
//
// Copyright (c) 2012-2017 Texas Instruments Incorporated.  All rights reserved.
// Software License Agreement
// 
// Texas Instruments (TI) is supplying this software for use solely and
// exclusively on TI's microcontroller products. The software is owned by
// TI and/or its suppliers, and is protected under applicable copyright
// laws. You may not combine this software with "viral" open-source
// software in order to form a larger program.
// 
// THIS SOFTWARE IS PROVIDED "AS IS" AND WITH ALL FAULTS.
// NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING, BUT
// NOT LIMITED TO, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE. TI SHALL NOT, UNDER ANY
// CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
// DAMAGES, FOR ANY REASON WHATSOEVER.
// 
// This is part of revision 2.1.4.178 of the EK-TM4C123GXL Firmware Package.
//
//*****************************************************************************

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "driverlib/adc.h"
#include "math.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/pwm.h"

uint32_t zhai[4];
uint32_t sum = 0;
float adcVal;
float distance;

//*****************************************************************************
//
//! \addtogroup example_list
//! <h1>UART Echo (uart_echo)</h1>
//!
//! This example application utilizes the UART to echo text.  The first UART
//! (connected to the USB debug virtual serial port on the evaluation board)
//! will be configured in 115,200 baud, 8-n-1 mode.  All characters received on
//! the UART are transmitted back to the UART.
//
//*****************************************************************************

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void
__error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

//*****************************************************************************
//
// The UART interrupt handler.
//
//*****************************************************************************


void
tainanle(void)
{
	ADCIntClear(ADC0_BASE,1);
	ADCSequenceDataGet(ADC0_BASE,1,zhai);

}


void ADC_init(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
    GPIOPinTypeADC(ADC0_BASE, GPIO_PIN_3);

    ADCSequenceConfigure(ADC0_BASE,1,ADC_TRIGGER_PROCESSOR,0);
    ADCSequenceStepConfigure(ADC0_BASE,1,0,ADC_CTL_CH0);
    ADCSequenceStepConfigure(ADC0_BASE,1,1,ADC_CTL_CH0);

    ADCSequenceStepConfigure(ADC0_BASE,1,2,ADC_CTL_CH0);

    ADCSequenceStepConfigure(ADC0_BASE,1,3,ADC_CTL_IE|ADC_CTL_END|ADC_CTL_CH0);


    ADCSequenceEnable(ADC0_BASE,1);
    ADCIntEnable(ADC0_BASE,1);
    IntEnable(INT_ADC0SS1);

}



main(void)
{




	//
    // Enable lazy stacking for interrupt handlers.  This allows floating-point
    // instructions to be used within interrupt handlers, but at the expense of
    // extra stack usage.
    //
    FPUEnable();
    FPULazyStackingEnable();

    //
    // Set the clocking to run directly from the crystal.
    //
    SysCtlClockSet(SYSCTL_SYSDIV_5 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN |
                    SYSCTL_XTAL_16MHZ);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    //  on-board LED.
    //

    //
    // Enable the GPIO pins for the LED (PF2).
    //
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_3);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1);

    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_2);




    //
    // Enable processor interrupts.

    //
    // Enable the UART interrupt.
    //




    //


    // Configure ADC
    ADC_init();
    IntMasterEnable();



    // set system clock and portE



    while(1)
    {
    	int i=0;

    		for(i = 0;i<4;i++)
    			{
    				 sum += zhai[i];
    			}
    		adcVal = zhai[1];


    		distance = -1.858203*pow(10,-9)*pow(adcVal, 3) + 1.3214630459*pow(10, -5)*pow(adcVal, 2) - 0.03356491643966*adcVal + 35.536853696418802;
    	SysCtlDelay(SysCtlClockGet() / (1000 * 3));

    	ADCProcessorTrigger(ADC0_BASE, 1);
    	if(distance >= 10.0)
    		{
    				GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_2, GPIO_PIN_3|GPIO_PIN_1);
    		}

       	if((distance >= 6.0)&& (distance<10.0))
        		{
       				GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_2, GPIO_PIN_3);

        		}
       	if(distance < 6.0)
        		{
       				GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1|GPIO_PIN_3|GPIO_PIN_2, GPIO_PIN_1);


        		}



    }
}

